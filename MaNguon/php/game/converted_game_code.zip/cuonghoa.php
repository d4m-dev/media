<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl='Cường hóa đồ';
require('../incfiles/head.php');
?>
<script language="javascript">
	$(document).ready(function(){
		$('.mainblok').on('click','#cuonghoa',function(){
			var vp=$('#item').val();
			var dch=$('select option:selected').val();
			$.ajax({
				url: 'load.php',
				type: 'POST',
				dataType: 'text',
				data: {
					vp: vp,
					dch: dch,
					submit: ""
				},
				success: function(result){
					$('.mainblok').html(result);
				}
			});
			return false;
		});
	});
</script>
<?php
echo '<div class="mainblok">';
$vp=(int)$_GET['id'];
$q=mysqli_query($conn, "SELECT * FROM `khodo` WHERE `id`='".$vp."' AND `user_id`='".$user_id."'");
$check=mysqli_num_rows($q);
if ($check<1) {
echo '<div class="rmenu">Bạn không có vật phẩm này!</div>';
} else {
$ok=mysqli_fetch_array($q);
$dch=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `vatpham` WHERE (`id_shop`='8' OR `id_shop`='9' OR `id_shop`='10' OR `id_shop`='11') AND `soluong`>'0' AND `user_id`='".$user_id."'"));
echo '<div class="phdr">Cường hóa vật phẩm</div>';
if (isset($_POST['submit'])) {
$da=(int)$_POST['dacuonghoa'];
$que=mysqli_query($conn, "SELECT * FROM `vatpham` WHERE `user_id`='".$user_id."' AND `id`='".$da."'");
$bug=mysqli_num_rows($que);
$pro=mysqli_fetch_array($que);
$shop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopvatpham` WHERE `id`='".$pro['id_shop']."'"));
if ($bug<1) {
echo '<div class="rmenu">ERROR!!!</div>';
} else if ($pro['id_shop']!=8&&$pro['id_shop']!=9&&$pro['id_shop']!=10&&$pro['id_shop']!=11) {
echo '<div class="rmenu">Đây không phải là đá cường hóa</div>';
} else if ($pro['soluong']<=0) {
echo '<div class="rmenu">Hết đá cường hóa rồi nhé!</div>';
} else {
$rand=(1+$ok['cong'])*2;
$randhp=(1+$ok['conghp'])*2;
$tile=rand(1,$rand);
$tilehp=rand(1,$randhp);
if ($pro['id_shop']==8||$pro['id_shop']==9) {
$smchia = $shop['tangsucmanh']/2;
$smchianho = $smchia/2;
$sm = $shop['tangsucmanh']-$smchia+$smchianho;
$randsm=rand($sm,$shop['tangsucmanh']);
$thanhcongsm=round($tile/2);
if ($tile==$thanhcongsm) {
mysqli_query($conn, "UPDATE `vatpham` SET `soluong`=`soluong`-'1' WHERE `user_id`='".$user_id."' AND `id_shop`='".$pro['id_shop']."'");
mysqli_query($conn, "UPDATE `khodo` SET `sucmanh`=`sucmanh`+'".$randsm."',`cong`=`cong`+'1' WHERE `user_id`='".$user_id."' AND `id`='".$vp."'");
echo '<div class="gmenu">Chúc mừng bạn đã cường hóa thành công vật phẩm <b>'.$ok['tenvatpham'].'</b>, vật phẩm tăng thêm <b>'.$randsm.' SM</b></div>';
} else {
mysqli_query($conn, "UPDATE `vatpham` SET `soluong`=`soluong`-'1' WHERE `user_id`='".$user_id."' AND `id_shop`='".$pro['id_shop']."'");
echo '<div class="rmenu">Cường hóa thất bại!</div>';
}
} else if ($pro[id_shop]==10||$pro[id_shop]==11) {
$hpchia = $shop['tanghp']/2;
$hpchianho = $hpchia/2;
$hp = $shop['tanghp']-$hpchia+$hpchianho;
$randhp=rand($hp,$shop[tanghp]);
$thanhconghp=round($tilehp/2);
if ($tilehp==$thanhconghp) {
mysqli_query($conn, "UPDATE `vatpham` SET `soluong`=`soluong`-'1' WHERE `user_id`='".$user_id."' AND `id_shop`='".$pro[id_shop]."'");
mysqli_query($conn, "UPDATE `khodo` SET `hp`=`hp`+'".$randhp."',`conghp`=`conghp`+'1' WHERE `user_id`='".$user_id."' AND `id`='".$vp."'");
echo '<div class="gmenu">Chúc mừng bạn đã cường hóa thành công vật phẩm <b>'.$ok[tenvatpham].'</b>, vật phẩm tăng thêm <b>'.$randhp.' HP</b></div>';
} else {
mysqli_query($conn, "UPDATE `vatpham` SET `soluong`=`soluong`-'1' WHERE `user_id`='".$user_id."' AND `id_shop`='".$pro[id_shop]."'");
echo '<div class="rmenu">Cường hóa thất bại!</div>';
}
}
}
}
echo '<form method="post"><input type="hidden" id="item" value="'.$vp.'"><img src="/images/shop/'.$ok[id_shop].'.png" class="avatar_vina"><b><font color="green">['.$ok[tenvatpham].']</font></b><br/>';
if ($dch<1) {
echo '<select disabled="disabled">
<option selected="selected">Không có đá cường hóa!</option>
</select><br/>';
echo '<input type="button" value="Cường hóa">';
} else {
$lay=mysqli_query($conn, "SELECT * FROM `vatpham` WHERE `user_id`='".$user_id."' AND `soluong`>'0' AND (`id_shop`='8' OR `id_shop`='9' OR `id_shop`='10' OR `id_shop`='11')");
echo '<select name="dacuonghoa">';
while ($in=mysqli_fetch_array($lay)) {
$n=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopvatpham` WHERE `id`='".$in[id_shop]."'"));
echo '<option value="'.$in[id].'" '.($da==$in[id]?'selected="selected"':'').'"> '.$n[tenvatpham].' ['.$in[soluong].' viên]</option>';
}
echo '</select><br/>';
echo '<input type="submit" name="submit" id="cuonghoa" value="Cường hóa">';
}
echo '</form>';
}
echo '</div>';
require('../incfiles/end.php');
?>