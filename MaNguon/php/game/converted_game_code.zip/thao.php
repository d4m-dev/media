<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
if ($datauser[id]==$user_id) {
if (isset($_POST[thao])) {
$vatpham=(int)$_POST[vatpham];
if (empty($vatpham)) {
header('Location: /ruong');
}
$check=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `id`='".$vatpham."' AND `user_id`='".$user_id."'"));
if ($check<1) {
echo '<div class="news">Bạn không có Vật Phẩm này!</div>';
} else {
$info=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `user_id`='".$user_id."' AND `id`='".$vatpham."'"));
$dangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `id_ruong`='".$info[id]."'"));
if ($dangmac<1) {
echo '<div class="news">Chưa mặc mà đòi cởi à!</div>';
} else {
@mysqli_query($conn, "UPDATE `users` SET `{$info['loai']}`='' WHERE `id`='".$user_id."'");
@mysqli_query($conn, "UPDATE `dangmac` SET `id_ruong`='', `id_loai` = ''  WHERE `user_id`='".$user_id."' AND `loai`='".$info[loai]."'");
header("Location: http://{$_SERVER['SERVER_NAME']}{$_SERVER['REQUEST_URI']}");
exit;
}
}
}
}
?>