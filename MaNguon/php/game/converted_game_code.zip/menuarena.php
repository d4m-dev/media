<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$thongtinonline1 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['user_id']."'"));
$thongtinonline2 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi']."'"));
$thongtinonline3 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi2']."'"));
$thongtinonline4 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi3']."'"));
if($areanonline['wait']==3) {
if ($areanonline['win'] == '0') {
echo'<div class="menu list-top">';
echo 'Thời gian chờ "'.(($areanonline['time']+30)-time()).'" giây<br/>Lượt Đi Của <span style="color:green;">'.nick($luotchoi).'</span><br/><a href="/boss/'.$id.'"><input type="button" value="Làm mới" /></a></div>';
}
}
$online1 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['user_id']."'"));
$online2 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi']."'"));
$online3 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi2']."'"));
$online4 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi3']."'"));
if ((time() > $online1['lastdate'] + 120)) {
mysqli_query($conn, "UPDATE `boss` SET `user_id`='0' WHERE `id`='".$id."'");
}
if ((time() > $online2['lastdate'] + 120)) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi`='0' WHERE `id`='".$id."'");
}
if ((time() > $online3['lastdate'] + 120)) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi2`='0' WHERE `id`='".$id."'");
}
if ((time() > $online4['lastdate'] + 120)) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi3`='0' WHERE `id`='".$id."'");
}
?>