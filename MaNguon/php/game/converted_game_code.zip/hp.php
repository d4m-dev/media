<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
$id = $_GET['id'];
$thongtinhp = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `boss_chien_arena` WHERE `phong`='".$id."'"));
if(empty($thongtinhp[phong])) {header('Location: '.$home.'');}
$per = floor(($thongtinhp['hp']*100)/$thongtinhp['hpfull']);
if($per>100){
$per=100;
} 
if($per<0){
$per=0;
} 
Header("Content-Type: Image/PNG");
$image=ImageCreateFromPNG("img/hp.png");
$bar=ImageCreateFromPNG("img/bar.png"); imagecopy($image, $bar,0, 0, 0, 0, $per,imagesy($bar)); ImagePNG($image);
ImageDestroy($image);
?>