<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$thongtinonline1 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['user_id']."'"));
$thongtinonline2 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi']."'"));
$thongtinonline3 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi2']."'"));
$thongtinonline4 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$areanonline['nguoichoi3']."'"));

if (empty($areanonline['user_id']) && empty($areanonline['nguoichoi']) && empty($areanonline['nguoichoi2']) && empty($areanonline['nguoichoi3'])) {
mysqli_query($conn, "DELETE FROM `boss` WHERE `id`='".$id."'");
mysqli_query($conn, "DELETE FROM `bosscmt` WHERE `sid`='".$id."'");
mysqli_query($conn, "DELETE FROM `boss_chien_arena` WHERE `phong`='".$id."'");
mysqli_query($conn, "DELETE FROM `boss_danh` WHERE `phong`='".$id."'");
mysqli_query($conn, "DELETE FROM `boss_noidung` WHERE `phong`='".$id."'");
mysqli_query($conn, "DELETE FROM `boss_notice` WHERE `phong`='".$id."'");
}
if (time() > $thongtinonline1['lastdate'] + 120) {
mysqli_query($conn, "UPDATE `boss` SET `user_id`='0' WHERE `id`='".$id."'");
}
if (time() > $thongtinonline2['lastdate'] + 120) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi`='0' WHERE `id`='".$id."'");
}
if (time() > $thongtinonline3['lastdate'] + 120) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi2`='0' WHERE `id`='".$id."'");
}
if (time() > $thongtinonline4['lastdate'] + 120) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi3`='0' WHERE `id`='".$id."'");
}
if (empty($areanonline['user_id'])) {
mysqli_query($conn, "UPDATE `boss` SET `user_id`= '".$areanonline['nguoichoi']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi`= '".$areanonline['nguoichoi2']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi2`= '".$areanonline['nguoichoi3']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi3`= '0' WHERE `id`='".$id."'");
header("Location: /boss/$id");
}
if (empty($areanonline['nguoichoi'])) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi`= '".$areanonline['nguoichoi2']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi2`= '".$areanonline['nguoichoi3']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi3`= '0' WHERE `id`='".$id."'");
}
if (empty($areanonline['nguoichoi2'])) {
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi2`= '".$areanonline['nguoichoi3']."' WHERE `id`='".$id."'");
mysqli_query($conn, "UPDATE `boss` SET `nguoichoi3`= '0' WHERE `id`='".$id."'");
}

?>