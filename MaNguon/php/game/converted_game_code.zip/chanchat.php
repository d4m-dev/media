<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Chặn chat';
if (!$user_id || $rights == 0)
{
	header('Location: /login.php');
	exit;
}
require('../incfiles/head.php');
$id = (int)$_GET['id'];
$check  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE id = '$id'"));
$row = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM users WHERE id = '$id'"));
if ($check < 1)
{
	echo '<div class="rmenu">Lỗi...</div>';
}
else
{
	if ($row['chanchat'] == 0)
	{
		mysqli_query($conn, "UPDATE users SET chanchat = '1' WHERE id = '$id'");
		header('Location: /member/'.$id.'.html');
	}
	else
	{
		mysqli_query($conn, "UPDATE users SET chanchat = '0' WHERE id = '$id'");
		header('Location: /member/'.$id.'.html');
	}
}
require('../incfiles/end.php');
?>