<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS',1);
require_once('../incfiles/core.php');
$textl='VI PHẠM';
require_once('../incfiles/head.php');
echo'<div class="main-xmenu">';
echo'<div class="danhmuc">Vi phạm của bạn</div>';
$vipham = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `cms_ban_users` WHERE `user_id`='" . $user_id. "'"));
$remain = $vipham['ban_time'] - time();
$period = $vipham['ban_time'] - $vipham['ban_while'];
$draan = $vipham['ban_while'] - time();
echo'<div class="list1">Đăng nhập không thành công !<br/>• Bạn bị khóa bởi : <b>'.$vipham['ban_who'].'</b><br/>• lý do bị khóa : '.$vipham['ban_reason'].'<br/>• Liên hệ Admin để biết thêm chi tiết<br/><center><a href="/exit.php">Trở lại đăng nhập</a></center></div>';
echo'</div>';
require_once('../incfiles/end.php');
?>