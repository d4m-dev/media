<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl='Mua vật phẩm cho nhóm';
require('../incfiles/head.php');
if (!$user_id) {
header('Location: /login.php');
exit;
}
$neptune=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `nhom` WHERE `user_id`='".$user_id."'"));
if (!$neptune) {
echo '<div class="phdr">Lỗi!</div>';
echo '<div class="rmenu">Bạn không có quyền thực hiện điều này</div>';
} else {
switch($act) {
case 'mua':
	$query=mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$id."' AND `clan`='1'");
	$num=mysqli_num_rows($query);
	$tontai=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `clan_kho` WHERE `vp`='".$id."' AND `clan`=".$neptune[id]."'"));
	$post=mysqli_fetch_array($query);
	echo '<div class="phdr">Mua '.$post[tenvatpham].'</div>';
	if (!$num) {
		echo '<div class="rmenu">Không tồn tại vât phẩm này!</div>';
	} else if ($tontai) {
		echo '<div class="rmenu">Nhóm bạn đã có vật phầm này</div>';
	} else {
		$nhom=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `nhom` WHERE `user_id`='".$user_id."'"));
		if ($post[loaitien]==xu) {
			if ($nhom[xu]<$post[gia]) {
				echo '<div class="rmenu">Không đủ tiền</div>';
			} else {
				mysqli_query($conn, "INSERT INTO `clan_kho` SET `clan`='".$nhom[id]."',`vp`='".$post[id]."'");
				mysqli_query($conn, "UPDATE `nhom` SET `xu`=`xu`-'".$post[gia]."' WHERE `user_id`='".$user_id."'");
				echo '<div class="menu">Mua thành công</div>';
			}
		} else {
			if ($nhom[luong]<$post[gia]) {
				echo '<div class="rmenu">Không đủ tiền</div>';
			} else {
				mysqli_query($conn, "INSERT INTO `clan_kho` SET `clan`='".$nhom[id]."',`vp`='".$post[id]."'");
				mysqli_query($conn, "UPDATE `nhom` SET `luong`=`luong`-'".$post[gia]."' WHERE `user_id`='".$user_id."'");
				echo '<div class="menu">Mua thành công</div>';
			}
		}
	}
break;
default:
echo '<div class="phdr">Mua vật phẩm</div>';
$tong=// mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `shopdo` WHERE `clan`='1'"));
$req=mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `clan`='1'");
while($res=mysqli_fetch_array($req)) {
echo '<div class="omenu"><img src="/images/shop/'.$res[id].'.png" class="avatar_vina">
<b><font color="green">['.$res[tenvatpham].']</font></b><br/>';
echo 'Giá: <font color="black"><b>'.$res[gia].'</b> '.($res[loaitien]=='xu'?'Xu':'Lượng').'</font><br/>';
echo '<a href="?act=mua&id='.$res[id].'"><input type="button" class="nut" value="Mua"></a><br/><br/></div>';
}
break;
}
}
require('../incfiles/end.php');
?>