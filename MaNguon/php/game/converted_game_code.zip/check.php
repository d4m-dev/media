<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
//--Thêm data vật phẩm by cRosSOver--//
$count=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `shopvatpham`"));
$i=1;
while ($i<=$count) {
$check=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `vatpham` WHERE `user_id`='".$user_id."' AND `id_shop`='".$i."'"));
if ($check<1) {
mysqli_query($conn, "INSERT INTO `vatpham` SET `user_id`='".$user_id."', `id_shop`='".$i."'");
}
$i++;
}
//End
//--Thêm data đang mặc--//
//áo
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='ao'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='ao'");
}
//quần
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='quan'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='quan'");
}
//cánh
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='canh'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='canh'");
}
//đồ cầm tay
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='docamtay'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='docamtay'");
}
//thú cưng
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='thucung'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='thucung'");
}
//hào quang
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='haoquang'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='haoquang'");
}
//mặt nạ
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='matna'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='matna'");
}
//kính
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='kinh'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='kinh'");
}
//khuôn mặt
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='khuonmat'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='khuonmat'");
}
//tóc
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='toc'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='toc'");
}
//tóc
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='mat'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='mat'");
}
//nón
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='non'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='non'");
}
//cần câu
$checkdangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='cancau'"));
if ($checkdangmac<1) {
mysqli_query($conn, "INSERT INTO `dangmac` SET `user_id`='".$user_id."', `loai`='cancau'");
}
//--Update HP AND SM--//
$tongsm = $datauser['smthem'];
$tonghp = $datauser['hpthem'];
$uphpsm=mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."'");
while($crossover=mysqli_fetch_array($uphpsm)) {
$ruong=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `user_id`='".$user_id."' AND `id`='".$crossover['id_ruong']."'"));
$tongsm+=$ruong['sucmanh'];
$tonghp+=$ruong['hp'];
}
if ($datauser['hp']>$datauser['hpfull']) {
mysqli_query($conn, "UPDATE `users` SET `hp`='".$datauser['hpfull']."' WHERE `id`='".$user_id."'");
}
mysqli_query($conn, "UPDATE `users` SET `sucmanh`='".$tongsm."' WHERE `id`='".$user_id."'");
mysqli_query($conn, "UPDATE `users` SET `hpfull`='".$tonghp."' WHERE `id`='".$user_id."'");
if ($datauser[hp]<0) {
mysqli_query($conn, "UPDATE `users` SET `hp`='0' WHERE `id`='".$user_id."'");
}
//--Update đồ--//
$querydo=mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."'");
while($updo=mysqli_fetch_array($querydo)) {
$checkruong=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `id`='".$updo['id_ruong']."' AND `user_id`='".$user_id."'"));
if ($checkruong<1) {
mysqli_query($conn, "UPDATE `dangmac` SET `id_loai`='',`id_ruong`='',`timesudung`='' WHERE `user_id`='".$user_id."' AND `loai`='".$updo['loai']."'");
}
if (!isset($_GET['xem_ok'])) {
mysqli_query($conn, "UPDATE `users` SET `".$updo['loai']."`='".$updo['id_loai']."' WHERE `id`='".$user_id."'");
}
}
//--Khu sinh thái--//
//rương cá
$checkca1=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_ca`='1'"));
if ($checkca1<1) {
mysqli_query($conn, "INSERT INTO `fish_ruong` SET `user_id`='".$user_id."', `id_ca`='1'");
}
$checkca2=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_ca`='2'"));
if ($checkca2<1) {
mysqli_query($conn, "INSERT INTO `fish_ruong` SET `user_id`='".$user_id."', `id_ca`='2'");
}
$checkca3=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_ca`='3'"));
if ($checkca3<1) {
mysqli_query($conn, "INSERT INTO `fish_ruong` SET `user_id`='".$user_id."', `id_ca`='3'");
}
?>