<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
defined('_IN_JOHNCMS')or die('access denined!!');
$mid=$res['id'];
$a=mysqli_query($conn, "select * from `forum_tags` where `mid`='$mid'")or die(mysqli_error($conn)));
if(mysqli_num_rows($a)){
$d=mysqli_fetch_array($a);
$ar=unserialize($d['text']);

$out='';
foreach($ar as $u =>$v){
if(!empty($out)) $out .=', ';
$out .='@<a href="'.$home.'/member/'.$u.'.html">'.nick($u).'</a>';
}
echo $out;
}
?>