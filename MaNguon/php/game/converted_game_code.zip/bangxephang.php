<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS', 1);
$headmod = 'khusinhthai';

$textl = 'Bảng xếp hạng câu cá';

echo'<div class="main-xmenu">';
echo '<div class="login"></font><div class="lucifer">';
echo'<div class="danhmuc">Top câu cá</div>';
echo'<div class="menu list-bottom congdong"><img src="'.$home.'/icon/user.png" alt="icon" style="vertical-align: -3px;"/> Xu: '.$datauser[xu].' - Câu được: '.$datauser[soca].' con cá </div>'; 
$tongso = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `users` WHERE `soca` > '0'"), 0);
$req = mysqli_query($conn, "SELECT * FROM `users` WHERE `soca` > '0' ORDER BY `soca` DESC LIMIT $start, $kmess");
while ($res = mysqli_fetch_array($req)) {
echo '<div class="menu list-bottom"><img src="'.$home.'/avatar/'.$res['id'].'.png" alt="'. $user['name'] . '" class="avatar_vina"/>
<a href="/member/'.$res['id'].'.html"><b>'.nick($res['id']).'</b></a><br/>
Câu được: '.$res['soca'].' con cá<br/><br/></div>';
}
if ($tongso > $kmess) {

}
echo'</div>';

?>