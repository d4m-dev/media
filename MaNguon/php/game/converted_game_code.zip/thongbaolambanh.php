<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$sqllambanh = mysqli_query($conn, "select * from `farm_nhabep_naubanh` WHERE `user_id` = '".$user_id."' AND `type` = '1' ORDER BY `id` DESC LIMIT $start, $kmess");
while ($thongtinbanh = mysqli_fetch_array($sqllambanh)){
$tenvatlieu = mysqli_fetch_array(mysqli_query($conn, "SELECT `tenvatlieu` FROM `farm_nhabep` WHERE `id`='".$thongtinbanh['loaibanh']."'"));
echo'<div class="thongbaomini"><img src="/farm/nhabep/icon/'.$thongtinbanh['loaibanh'].'.png" alt="icon" /> '.htmlspecialchars($tenvatlieu['tenvatlieu']).' đã chín rồi vào <a href="/farm/nhabep/?id='.$thongtinbanh['loaibanh'].'">[ <b>đổi điểm</b> ]</a> thôi !</div>';
if (($thongtinbanh[time] + $thongtinbanh['timexong']) < $time) {
mysqli_query($conn, "UPDATE `farm_nhabep_naubanh` SET `type` = '1', `timexong` = '0', `time` = '0' WHERE `id` = $user_id LIMIT 1");
}
}
$sqltimebanh = mysqli_query($conn, "select * from `farm_nhabep_naubanh` WHERE `user_id` = '".$user_id."' AND `type` = '0' ORDER BY `id` DESC LIMIT $start, $kmess");
while ($timebanh = mysqli_fetch_array($sqltimebanh)){
if (($timebanh[time] + $timebanh['timexong']) < $time) {
mysqli_query($conn, "UPDATE `farm_nhabep_naubanh` SET `type` = '1', `timexong` = '0', `time` = '0' WHERE `user_id` = $user_id LIMIT 1");
}
}
?>