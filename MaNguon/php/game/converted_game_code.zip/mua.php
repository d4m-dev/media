<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
/* 
Code pokemon được viết bởi Châu Huỳnh
Vui Lòng Để Bản Quyền Nếu Bạn Là Người Có Học
Site : DanChoiViet.Me
*/
define('_IN_JOHNCMS',1);
$rootpath='../../';
include'../incfiles/core.php';
include'../incfiles/head.php';
if(!$user_id){
echo'Đăng Nhập Đi';
include'../incfiles/end.php';
exit;
}
$id =$_SERVER['QUERY_STRING'];
$id =  str_replace('id=','',$id);
$id = intval($id);
echo'<div class="phdr">Tạo Nhân Vật</div>';
$check = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shoppkm1` WHERE `id`='".$id."'"));
$check['gia']= intval($check['gia']);
$check['name'] = addslashes($check['name']);
$check['hp'] = intval($check['hp']);
$check['sm']=intval($check['sm']);
$check['img']=addslashes($check['img']);
if(empty($check['id'])){
echo'PokéMon không tồn tại';
}else
if($datauser['vnd']<$check['gia']){
echo'Ko đủ lượng để tạo nhân vật này! <br><br><div><div>';
}else

if($datauser['vnd']>=$check['gia']){
$time2 = time();
$tuipkmi = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `tuipkm1` WHERE `user_id`='{$user_id}'"), 0);
if($tuipkmi == 0) {
mysqli_query($conn, "INSERT INTO `tuipkm1` SET `user_id`='" . $user_id. "',`hp`='" . $check['hp'] . "',`sm`='" . $check['sm']. "',`time`='".$time2."',`img`='" . $check['img'] . "',`name`='" . $check['name'] . "',`hpfull`='" . $check['hp'] . "',`idpkm`='{$id}'");
}
if($tuipkmi > 0) {
@mysqli_query($conn, "update `tuipkm1` set `hp`='".$check['hp']."',`sm`='".$check['sm']."',`hpfull`='".$check['hp']."',`img`='".$check['img']."',`name`='".$check['name']."' where `id` = '" . $user_id . "',`idpkm`='{$id}'");
}
@mysqli_query($conn, "update `users` set `vnd` = `vnd`-'" . $check['gia']. "' where `id` = '" . $user_id . "'");
$time = time();
$bot = ' @'.$login.' Vừa Mua Thành Công '.$check['name'].' [img]'.$check['img'].'[/img]';
mysqli_query($conn, "INSERT INTO `guest` SET
`adm` = '0',
`time` = '$time',
`user_id` = '2',
`name` = 'BOT',
`text` = '" . mysqli_real_escape_string($conn, $bot) . "',
`ip` = '0000',
`browser` = 'IPHONE'
");
echo'<div class="da"><div class="lucifer">Bạn Vừa Mua Thành Công '.$check['name'].' <img src="'.$check ['img'].'">';
}

echo'<a href="/idthienan_5ltb"><button type="button" class="btn btn-light">Vào Làng 5LTB!</button></a>';

include'../incfiles/end.php';