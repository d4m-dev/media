<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
if ($datauser[id]==$user_id) {
if (isset($_POST[mac])) {
$vatpham=(int)$_POST[vatpham];
if (empty($vatpham)) {
header("Location: /ruong");
}
$check=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `id`='".$vatpham."' AND `user_id`='".$user_id."'"));
if ($check<1) {
echo '<div class="news">Bạn không có Vật Phẩm này!</div>';
} else {
//Khai báo
$info=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `khodo` WHERE `user_id`='".$user_id."' AND `id`='".$vatpham."'"));
$dangmac=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `dangmac` WHERE `user_id`='".$user_id."' AND `loai`='".$info[loai]."'"));
if ($info[loai]=='cancau') {
mysqli_query($conn, "UPDATE `users` SET `savecancau`='".$info[id_loai]."' WHERE `id`='".$user_id."'");
}
@mysqli_query($conn, "UPDATE `users` SET `{$info['loai']}`='".$info[id_loai]."' WHERE `id`='".$user_id."'");
@mysqli_query($conn, "UPDATE `dangmac` SET `id_ruong`='".$info[id]."', `id_loai` = '".$info[id_loai]."',`timesudung`='".$info[timesudung]."'  WHERE `user_id`='".$user_id."' AND `loai`='".$info[loai]."'");
header("Location: http://{$_SERVER['SERVER_NAME']}{$_SERVER['REQUEST_URI']}");
exit;
}
}
}
?>