<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?PHP
Define('_IN_JOHNCMS', 1);
Require('../incfiles/core.php');
$headmod = 'PK';
$textl = 'PK';
Require('../incfiles/head.php');
IF(!$user_id){
Header("Location: /");
Exit;
}
Echo'<div class="box_forums"><br/><div class="homeforum"><div class="icon-home"><div class="home">Chiến trường</div></div></div></div><div class="phdr">Chiến trường</div>';
session_start();
$id=(int)$_GET[id];
$uid=mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$id."'");
$num=mysqli_num_rows($uid);
$x=mysqli_fetch_array($uid);
IF($datauser['hp']<=0&&$x[hp]<=0&&$num<1&&$id=$user_id&&$_SESSION['PK']>time()){Header('Location:/vuichoi');Exit;}
IF($x['timepk']>time()){
$time=time()-300;
$v=mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `vitri` WHERE `id`='".$id."' AND `time`>'".$time."'"));
$d=rand($datauser[sucmanh]/10*10,($datauser[sucmanh]/10*15));
mysqli_query($conn, "UPDATE `users` SET `hp`=`hp`-'".$d."' WHERE `id`='".$x[id]."'");
$s=rand(1,30);
IF($x[id]==3){
$pk_user=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `pk_user` WHERE `user_id`='".$user_id."'"));
IF($Check <= 0 && $x[hp] > 0){
mysqli_query($conn, "INSERT INTO `pk_user` SET `user_id`='".$user_id."'");
}
}
IF($d>=$x[hp]&&$x[hp]>0){
mysqli_query($conn, "UPDATE `users` SET `pk`=`pk`+'1' WHERE `id`='".$user_id."'");
}
$m='[blue]'.$datauser[name].'[/blue] vừa đánh [blue]'.$x[name].'[/blue] mất [red]'.$d.'[/red] HP';
mysqli_query($conn, "INSERT INTO `pk` SET `user_id`='2', `text`='".mysqli_real_escape_string($conn, $m)."', `time`='".time()."'");
$_SESSION['PK']=time()+999;
Header('Location: /vuichoi');
}Else{
Echo'<div class="omenu"><center><b><font color="red">LỖI !<br>ĐỐI THỦ ĐÃ RỜI TRẬN</font></b></center></div>';
}
Require('../incfiles/end.php');
