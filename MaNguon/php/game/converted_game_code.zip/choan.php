<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
if(isset($_GET['chogaan'])) {
mysqli_query($conn, "UPDATE `farm_vatnuoi_choan` SET 
`timean` = '".time()."',
`xem` = '0',
`tinhtrang` = '2' WHERE `vatnuoi` = '1' AND `user_id` = '".$user_id."'");
header('Location: '.$home.'/farm/');
}
if(isset($_GET['choheocuuboan'])) {
mysqli_query($conn, "UPDATE `farm_vatnuoi_choan` SET 
`timean` = '".time()."',
`xem` = '0',
`tinhtrang` = '2' WHERE `vatnuoi` = '2' AND `user_id` = '".$user_id."' LIMIT 1");

mysqli_query($conn, "UPDATE `farm_vatnuoi_choan` SET 
`timean` = '".time()."',
`xem` = '0',
`tinhtrang` = '2' WHERE `vatnuoi` = '3' AND `user_id` = '".$user_id."' LIMIT 1");

mysqli_query($conn, "UPDATE `farm_vatnuoi_choan` SET 
`timean` = '".time()."',
`tinhtrang` = '2' WHERE `vatnuoi` = '4' AND `user_id` = '".$user_id."' LIMIT 1");
header('Location: '.$home.'/farm/');
}
if(isset($_GET['chocaan'])) {
mysqli_query($conn, "UPDATE `farm_vatnuoi_choan` SET 
`timean` = '".time()."',
`xem` = '0',
`tinhtrang` = '2' WHERE `vatnuoi` = '5' AND `user_id` = '".$user_id."'");
header('Location: '.$home.'/farm/');
}
?>