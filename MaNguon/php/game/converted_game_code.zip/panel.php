<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
/* 
Code pokemon được viết bởi Châu Huỳnh
Vui Lòng Để Bản Quyền Nếu Bạn Là Người Có Học
Site : DanChoiViet.Me
*/
define('_IN_JOHNCMS',1);
$rootpath ='../../';
include'../incfiles/core.php';
include'../incfiles/head.php';
echo'<div class="phdr">Danh Sách PoKéMon</div>';
$newticker = mysqli_query($conn, "SELECT * FROM `tuipkm` WHERE `id` ORDER BY `time` DESC LIMIT $start , $kmess");
while ($arr = mysqli_fetch_array($newticker)) {
echo'<div class="list2">'.nick($arr['user_id']).' : <img src="'.$arr['img'].'"> : Level : '.$arr['lv'].' </div>';
}
include'../incfiles/end.php';