<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php

if(isset($_GET['batdau']) && $user_id==$areanonline['user_id'] && $areanonline['wait']!=3) {
if (!empty($areanonline['nguoichoi'])) {
mysqli_query($conn, "UPDATE `boss` SET `wait`='3',`time`='".time()."' WHERE `id`='$id'");
mysqli_query($conn, "DELETE FROM `boss_notice` WHERE `phong`='".$id."'");
mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`-'200' WHERE `id`='".$areanonline['user_id']."'");
mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`-'200' WHERE `id`='".$areanonline['nguoichoi']."'");
mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`-'200' WHERE `id`='".$areanonline['nguoichoi2']."'");
mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`-'200' WHERE `id`='".$areanonline['nguoichoi3']."'");
mysqli_query($conn, "UPDATE `users` SET `phongbossdangchoi`= '".$id."' WHERE `id`='".$areanonline['user_id']."'");
mysqli_query($conn, "UPDATE `users` SET `phongbossdangchoi`= '".$id."' WHERE `id`='".$areanonline['nguoichoi']."'");
mysqli_query($conn, "UPDATE `users` SET `phongbossdangchoi`= '".$id."' WHERE `id`='".$areanonline['nguoichoi2']."'");
mysqli_query($conn, "UPDATE `users` SET `phongbossdangchoi`= '".$id."' WHERE `id`='".$areanonline['nguoichoi3']."'");
mysqli_query($conn, "UPDATE `boss` SET `cuaai`= '1' WHERE `id`='".$id."'");
header("Location: /boss/$id");
} else {
echo '<div class="menu">Trận đấu phải trên 2 người mới có thể bắt đầu !</div>';
echo'<a href="/boss/'.$id.'"><input type="button" value="Trở về"/></a>';
echo '</div>';
require('../incfiles/end.php');
exit;
}
}

?>