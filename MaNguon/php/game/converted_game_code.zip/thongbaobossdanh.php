<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php


if($areanonline['win'] == 0) {
if($areanonline['wait'] == 3) {
$bossdanh = mysqli_query($conn, "SELECT * FROM `boss_danh` WHERE `phong` = '".$id."' ORDER BY `time` DESC LIMIT 1");
while ($res = mysqli_fetch_array($bossdanh)) {
echo'<div class="menu list-top hot">';
if ($res['type'] == '1'){
echo'<img src="'.$home.'/icon/khudautruong.png" alt="Chiến đấu" style="vertical-align: -3px;"/>&#160;';
echo'Boss vừa đánh "'.nick($res[nguoibidanh]).'" mất '.$res[sodanh].' HP haha...';
}
echo'</div>';
}
}
}
?>