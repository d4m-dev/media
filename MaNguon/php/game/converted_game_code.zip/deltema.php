<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php

/*
////////////////////////////////////////////////////////////////////////////////
// JohnCMS                Mobile Content Management System                    //
// Project site:          http://johncms.com                                  //
// Support site:          http://gazenwagen.com                               //
////////////////////////////////////////////////////////////////////////////////
// Lead Developer:        Oleg Kasyanov   (AlkatraZ)  alkatraz@gazenwagen.com //
// Development Team:      Eugene Ryabinin (john77)    john77@gazenwagen.com   //
//                        Dmitry Liseenko (FlySelf)   flyself@johncms.com     //
////////////////////////////////////////////////////////////////////////////////
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
if ($rights >= 3) {
    if (!$id) {
        require('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require('../incfiles/end.php');
        exit;
    }
    // Проверяем, существует ли тема
    $req = mysqli_query($conn, "SELECT * FROM `forum` WHERE `id` = '$id' AND `type` = 't'");
    if (!mysqli_num_rows($req)) {
        require('../incfiles/head.php');
        echo functions::display_error($lng_forum['error_topic_deleted']);
        require('../incfiles/end.php');
        exit;
    }
    $res = mysqli_fetch_assoc($req);
    if (isset($_POST['submit'])) {
        $del = isset($_POST['del']) ? intval($_POST['del']) : NULL;
        if ($del == 2 && core::$user_rights >= 7) {
            /*
            -----------------------------------------------------------------
            Удаляем топик
            -----------------------------------------------------------------
            */
            $req1 = mysqli_query($conn, "SELECT * FROM `cms_forum_files` WHERE `topic` = '$id'");
            if (mysqli_num_rows($req1)) {
                while ($res1 = mysqli_fetch_assoc($req1)) {
                    unlink('../files/forum/attach/' . $res1['filename']);
                }
                mysqli_query($conn, "DELETE FROM `cms_forum_files` WHERE `topic` = '$id'");
                mysqli_query($conn, "OPTIMIZE TABLE `cms_forum_files`");
            }
            mysqli_query($conn, "DELETE FROM `forum` WHERE `refid` = '$id'");
            mysqli_query($conn, "DELETE FROM `forum` WHERE `id`='$id'");
        } elseif ($del = 1) {
            /*
            -----------------------------------------------------------------
            Скрываем топик
            -----------------------------------------------------------------
            */
            mysqli_query($conn, "UPDATE `forum` SET `close` = '1', `close_who` = '$login' WHERE `id` = '$id'");
            mysqli_query($conn, "UPDATE `cms_forum_files` SET `del` = '1' WHERE `topic` = '$id'");
        }
        header('Location: /forums/' . $res['refid'] . '.html');
    } else {
        /*
        -----------------------------------------------------------------
        Меню выбора режима удаления темы
        -----------------------------------------------------------------
        */
        require('../incfiles/head.php');
        echo '<div class="phdr">Xoá bài viết này</div>' .
             '<div class="mainbody">' .
             '<div class="menu"><form method="post" action="index.php?act=deltema&amp;id=' . $id . '">' .
             '<p><b>Bạn thật sự muốn xoá bài viết này</b><br/>' .
             (core::$user_rights >= 7 ? '<input type="radio" value="2" name="del"checked="checked" />&#160;' . $lng['delete'] . '</p>' : '') .
             '<p><input type="submit" name="submit" value="Đồng ý" /></p>' .
             '</p></form></div></div>';
    }
} else {
    echo functions::display_error($lng['access_forbidden']);
}