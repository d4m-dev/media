<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$time = time();
if($user_id){
include 'str.php';
$post = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "select count(*) from `fermer_gr` WHERE  `id_user` = '{$user_id}'  LIMIT 1"),0);
if($post<5){
mysqli_query($conn, "INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user_id."') ");
mysqli_query($conn, "INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user_id."') ");
mysqli_query($conn, "INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user_id."') ");
mysqli_query($conn, "INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user_id."') ");
mysqli_query($conn, "INSERT INTO `fermer_gr` (`kol`,`semen`, `id_user`) VALUES  ( NULL, '0', '".$user_id."') ");
}
}
?>