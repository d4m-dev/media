<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
error_reporting(0);
//connect
$conn = mysqli_connect('localhost', 'nghiafun_game24h', 't1i4c1N2') or die('Không thể kết nối CSDL');
mysql_select_db('nghiafun_game24h');
mysqli_query($conn, "UPDATE `users` SET `baodanh` = '0', `nhanhopqua` = '0', `chanchat`='0'");
mysqli_query($conn, "DELETE FROM `nhiemvu_user`");
mysqli_query($conn, "DELETE FROM `naruto_nhiemvu`");
?>