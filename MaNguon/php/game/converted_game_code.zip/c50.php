<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
defined('_IN_JOHNCMS') or die ('Error: restricted access');
$db_host = 'localhost';
$db_name = 'nghiafun_game24h';
$db_user = 'nghiafun_game24h';
$db_pass = 't1i4c1N2';
$baotri = 'Bao tri de fix 1 so loi. Vui long quay lai vao ngay mai!';
$conn = @mysqli_connect("{$db_host}", "{$db_user}", "{$db_pass}") or die("$baotri");
@mysql_select_db("{$db_name}") or die("$baotri");
mysqli_query($conn, "SET character_set_results=utf8", $conn);
mb_internal_encoding('UTF-8');
mysqli_query($conn, "set names 'utf8'",$conn);
?>