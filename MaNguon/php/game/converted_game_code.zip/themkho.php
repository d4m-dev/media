<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if (!$rights == 9) {
header("Location: $home");
}
$textl = 'Thêm vật nuôi';
require('../incfiles/head.php');
echo'<div class="main-xmenu">';
echo'<div class="danhmuc">Thêm vật nuôi</div>';
$ten = $_POST['ten'];
if(isset($_POST['submit'])){
mysqli_query($conn, "INSERT INTO `fermer_name` SET 
`name`='".$ten."'
");

$insertid = mysqli_insert_id($conn));
header("Location: $home/farm/");
} else {
echo'<form enctype="multipart/form-data" method="post">';
echo'<div class="menu">';
echo'Tên : <input type="text" name="ten" /><br/>';
echo'<input type="submit" name="submit" value="Lưu lại" name="submit" />';
echo'</form>';
echo'</div>';
}
echo'</div>';
require_once('../incfiles/end.php');
?>