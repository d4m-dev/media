<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php

/*
Mod in đậm Hoàng Anh
Mod này chỉ in đậm ko lên trang nhất !
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($rights == 8 || $rights >= 9) {
    if (empty($_GET['id'])) {
        require('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require('../incfiles/end.php');
        exit;
    }
    $req = mysqli_query($conn, "SELECT COUNT(*) FROM `forum` WHERE `id` = '" . $id . "' AND `type` = 't'");
    if (// mysql_result not supported in mysqli. Needs manual rewrite.$req, 0) > 0) {
        mysqli_query($conn, "UPDATE `forum` SET  `topicvip` = '" . (isset($_GET['topicvip']) ? '1' : '0') . "' WHERE `id` = '$id'");
        header('Location: '.$id.'.html');
    } else {
        require('../incfiles/head.php');
        echo functions::display_error($lng['error_wrong_data']);
        require('../incfiles/end.php');
        exit;
    }
}

?>