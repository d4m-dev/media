<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?PHP
$headmod = 'Làng cổ';
$textl = 'Làng cổ';
$req = mysqli_query($conn, "SELECT * FROM `langtruyenthuyet_boss`");
while($res = mysqli_fetch_assoc($req)){
if($datauser['level'] >= $res['lvboss'] || $datauser['level'] < $res['lvbossmax']){
if($res['hienthi'] == 0){
if(time() > $res['timebosschet'] + 60 ){
mysqli_query($conn, "UPDATE `langtruyenthuyet_boss` SET `hienthi`='1'");
mysqli_query($conn, "UPDATE `langtruyenthuyet_boss` SET `hp`=`hpfull`");
}
}
}
}
?>