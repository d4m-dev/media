<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php

define('_IN_JOHNCMS',1);

require('incfiles/core.php');

if(!$user_id){ echo '<div class="menu">Hãy đăng nhập để sử dụng</div>';
require('incfiles/end.php'); exit; }

$set_mail = unserialize($user['set_mail']);
$out = '';
$total = 0;
$ch = 0;
$mod = isset($_REQUEST['mod']) ? $_REQUEST['mod'] : '';

if(!$id){ echo '<div class="menu">Hãy Chat với một người nào đó. Hiện tại ID đang trống</div>';
require('incfiles/end.php'); exit; }

if ($id) {
    $req = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");
    if (mysqli_num_rows($req) == 0) {
  echo '<div class="menu">Thành viên này không tồn tại</div>';
    }
    $qs = mysqli_fetch_assoc($req);
   
}

if (empty($_SESSION['error'])) {
    $_SESSION['error'] = '';
}


if (isset($_POST['msg']) && empty($ban['1']) && empty($ban['3']) && !functions::is_ignor($id)) {
 
    $text = isset($_POST['msg']) ? trim($_POST['msg']) : '';
    $newfile = '';
    $sizefile = 0;
    $do_file = FALSE;
    $do_file_mini = FALSE;

    $error = array();

    if (!$id && empty($name))
        $error[] = $lng_mail['indicate_login_grantee'];
    if (empty($text))
        $error[] = $lng_mail['message_not_empty'];
    elseif (mb_strlen($text) < 2 || mb_strlen($text) > 5000)
        $error[] = $lng_mail['error_long_message'];
    if (($id && $id == $user_id) || !$id && $datauser['name_lat'] == $name)
        $error[] = $lng_mail['impossible_add_message'];
    $flood = functions::antiflood();
    if ($flood)
        $error[] = $lng['error_flood'] . ' ' . $flood . $lng['sec'];
    if (empty($error)) {
        if (!$id) {
            $query = mysqli_query($conn, "SELECT * FROM `users` WHERE `name_lat`='" . mysqli_real_escape_string($conn, $name) . "' LIMIT 1");
            if (mysqli_num_rows($query) == 0) {
                $error[] = $lng['error_user_not_exist'];
            } else {
                $user = mysqli_fetch_assoc($query);
                $id = $user['id'];
                $set_mail = unserialize($user['set_mail']);
            }
        } else {
            $set_mail = unserialize($qs['set_mail']);
        }

        if (empty($error)) {
            if ($set_mail) {
                if ($rights < 1) {
                    if ($set_mail['access']) {
                        if ($set_mail['access'] == 1) {
                            $query = mysqli_query($conn, "SELECT * FROM `cms_contact` WHERE `user_id`='" . $id . "' AND `from_id`='" . $user_id . "' LIMIT 1");
                            if (mysqli_num_rows($query) == 0) {
                                $error[] = $lng_mail['write_contacts'];
                            }
                        } else if ($set_mail['access'] == 2) {
                            $query = mysqli_query($conn, "SELECT * FROM `cms_contact` WHERE `user_id`='" . $id . "' AND `from_id`='" . $user_id . "' AND `friends`='1' LIMIT 1");
                            if (mysqli_num_rows($query) == 0) {
                                $error[] = $lng_mail['write_friends'];
                            }
                        }
                    }
                }
            }
        }
    }

  

    $info = array();
    if (empty($error)) {
        $ignor = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `cms_contact`
		WHERE `user_id`='" . $user_id . "'
		AND `from_id`='" . $id . "'
		AND `ban`='1';"), 0);
        if ($ignor)
            $error[] = $lng_mail['error_user_ignor_in'];
        if (empty($error)) {
            $ignor_m = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `cms_contact`
			WHERE `user_id`='" . $id . "'
			AND `from_id`='" . $user_id . "'
			AND `ban`='1';"), 0);
            if ($ignor_m)
                $error[] = $lng_mail['error_user_ignor_out'];
        }
    }

    if (empty($error)) {
        $q = mysqli_query($conn, "SELECT * FROM `cms_contact`
		WHERE `user_id`='" . $user_id . "' AND `from_id`='" . $id . "';");
        if (mysqli_num_rows($q) == 0) {
            mysqli_query($conn, "INSERT INTO `cms_contact` SET
			`user_id` = '" . $user_id . "',
			`from_id` = '" . $id . "',
			`time` = '" . time() . "'");
            $ch = 1;
        }
        $q1 = mysqli_query($conn, "SELECT * FROM `cms_contact`
		WHERE `user_id`='" . $id . "' AND `from_id`='" . $user_id . "';");
        if (mysqli_num_rows($q1) == 0) {
            mysqli_query($conn, "INSERT INTO `cms_contact` SET
			`user_id` = '" . $id . "',
			`from_id` = '" . $user_id . "',
			`time` = '" . time() . "'");
            $ch = 1;
        }

    }


   
    // Проверяем на повтор сообщения
    if (empty($error)) {
        $rq = mysqli_query($conn, "SELECT * FROM `cms_mail`
        WHERE `user_id` = $user_id
        AND `from_id` = $id
        ORDER BY `id` DESC
        LIMIT 1
        ") or die(mysqli_error($conn)));
        $rres = mysqli_fetch_assoc($rq);
        if ($rres['text'] == $text) {
            $error[] = $lng['error_message_exists'];
        }
    }


    if (empty($error)) {
        mysqli_query($conn, "INSERT INTO `cms_mail` SET
		`user_id` = '" . $user_id . "',
		`from_id` = '" . mysqli_real_escape_string($conn, intval($id)) . "',
		`text` = '" . mysqli_real_escape_string($conn, $text) . "',
		`time` = '" . time() . "',
		`file_name` = '" . mysqli_real_escape_string($conn, $newfile) . "',
		`size` = '10'") or die(mysqli_error($conn)));

        mysqli_query($conn, "UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '$user_id';");
        if ($ch == 0) {
            mysqli_query($conn, "UPDATE `cms_contact` SET `time` = '" . time() . "' WHERE `user_id` = '" . $user_id . "' AND
			`from_id` = '" . intval($id) . "';");
            mysqli_query($conn, "UPDATE `cms_contact` SET `time` = '" . time() . "' WHERE `user_id` = '" . intval($id) . "' AND
			`from_id` = '" . $user_id . "';");
        }
      
    } else {
        $out .= '<div class="rmenu">' . implode('<br />', $error) . '</div>';
    }
}

if (!functions::is_ignor($id) && empty($ban['1']) && empty($ban['3'])) {

    $out .= isset($_SESSION['error']) ? $_SESSION['error'] : '';
  
}

if ($id) {
                  $item_onl .= (time() > $qs['lastdate'] + 300 ? ' đã Offline' : ' <font color=green><font size=3> •</font></font> đang hoạt động'); 
                  $out .= '<div class="menu">Chat với <b>'.$qs['name'].'</b> ( '.$item_onl.' )</div>';

    $total = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `cms_mail` WHERE ((`user_id`='$id' AND `from_id`='$user_id') OR (`user_id`='$user_id' AND `from_id`='$id')) AND `sys`!='1' AND `delete`!='$user_id' AND `spam`='0'"), 0);

    if ($total) {

        if ($total > $kmess) $out .= '<div class="topmenu">' . functions::display_pagination(''.$home.'/mail.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';

        $req = mysqli_query($conn, "SELECT `cms_mail`.*, `cms_mail`.`id` as `mid`, `cms_mail`.`time` as `mtime`, `users`.*
            FROM `cms_mail`
            LEFT JOIN `users` ON `cms_mail`.`user_id`=`users`.`id`
            WHERE ((`cms_mail`.`user_id`='$id' AND `cms_mail`.`from_id`='$user_id') OR (`cms_mail`.`user_id`='$user_id' AND `cms_mail`.`from_id`='$id'))
            AND `cms_mail`.`delete`!='$user_id'
            AND `cms_mail`.`sys`!='1'
            AND `cms_mail`.`spam`='0'
            ORDER BY `cms_mail`.`time` DESC
            LIMIT " . $start . "," . $kmess);
        $i = 1;
        $mass_read = array();
        while (($row = mysqli_fetch_assoc($req)) !== FALSE) {
            if (!$row['read']) {
                $out .= '<div class="menu">';
                $item = '<i class="fa fa-share"></i>';
            } else {
                   $item = '';
                if ($row['from_id'] == $user_id) {
                    $out .= '<div class="menu">';
                } else {
                    $out .= '<div class="menu">';
                }
            }
            if ($row['read'] == 0 && $row['from_id'] == $user_id)
                $mass_read[] = $row['mid'];
            $post = $row['text'];
            $post = functions::checkout($post, 1, 1);
            if ($set_user['smileys'])
                $post = functions::smileys($post, $row['rights'] >= 1 ? 1 : 0);
         
            //$subtext = '<a href="index.php?act=delete&amp;id=' . $row['mid'] . '">' . $lng['delete'] . '</a>';
         
 
            $out .= functions::NickName($row['user_id']).' : '.$post.'<div class="right">'.$item.'</div></div>';
     
            ++$i;
        }
        //Ставим метку о прочтении
        if ($mass_read) {
            $result = implode(',', $mass_read);
            mysqli_query($conn, "UPDATE `cms_mail` SET `read`='1' WHERE `from_id`='$user_id' AND `id` IN (" . $result . ")");
        }
    } else {
        $out .= '<div class="menu"><p>' . $lng['list_empty'] . '</p></div>';
    }

  
}

echo $out;

/*
echo '<p>';
if ($total) {
    echo '<a href="index.php?act=write&amp;mod=clear&amp;id=' . $id . '">' . $lng_mail['clear_messages'] . '</a><br/>';
}
*/

unset($_SESSION['error']);