<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
$headmod='theo dõi chủ đề';
$t=intval($_GET['t']);
$checktop=mysqli_num_rows(mysqli_query($conn, "select `id` from `forum` where `id`='$t' and `type`='t'"));
if(!$checktop){
echo functions::display_error('tình trạng dữ liệu');
require_once('../incfiles/end.php');
exit;
}
$sql=mysqli_query($conn, "select * from `forum_theodoi` where `uid`='$user_id' and `tid`='$t'");
$input1=mysqli_num_rows($sql);
if($_POST['submit'])
{
if($input1){
mysqli_query($conn, "delete from `forum_theodoi` where `uid`='$user_id' and `tid`='$t'")or die(mysqli_error($conn)));
}else{
mysqli_query($conn, "insert into `forum_theodoi` set `uid`='$user_id', `tid`='$t'")or die(mysqli_error($conn)));
}
header('Location: /forum/'.$t.'.html');
} else {
if($input1)
$te='B&#7887; '; else $te='';
echo '<div class="mainblok"><div class="phdr">'.$te.'Theo dõi</div><div class="menu">Bạn muối '.$te.' theo dõi bài viết này?</div><p align="center"><form method="post"><input type="submit" name="submit" value="Đồng ý"></form></div>';
}
require_once('../incfiles/end.php');
?>
