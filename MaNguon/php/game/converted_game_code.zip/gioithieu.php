<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
                                                                 <?php
$gt=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `users` WHERE `gioithieu`='".$user_id."'"));
//Cột mốc 1 -- 10 người
if ($gt>=10) {
	$cotmoc=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `lichsuqua_gioithieu` WHERE `user_id`='".$user_id."' AND `cotmoc`='1' AND `nhan`='1'"));
	if (!$cotmoc) {
		$xu=500000; $vnd=5;
		mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`+'".$xu."',`vnd`=`vnd`+'".$vnd."' WHERE `id`='".$user_id."'"); //Quà tiền 
		$idshop=787; //->Thay id shop
		$quashop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$idshop."'"));
		mysqli_query($conn, "INSERT INTO `khodo` SET 
		`user_id`='".$user_id."', 
		`id_shop`='".$idshop."',
		`id_loai`='".$quashop['id_loai']."',
		`loai`='".$quashop['loai']."',
		`tenvatpham`='".$quashop['tenvatpham']."'
		");
		mysqli_query($conn, "INSERT INTO `lichsuqua_gioithieu` SET `user_id`='".$user_id."', `nhan`='1' , `cotmoc`='1'");
	}
}
//Cột mốc 2 -- 25 người
if ($gt>=25) {
	$cotmoc=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `lichsuqua_gioithieu` WHERE `user_id`='".$user_id."' AND `cotmoc`='2' AND `nhan`='1'"));
	if (!$cotmoc) {
		$xu=2000000; $vnd=10;
		mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`+'".$xu."',`vnd`=`vnd`+'".$vnd."' WHERE `id`='".$user_id."'"); //Quà tiền 
		$idshop=788; //->Thay id shop
		$quashop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$idshop."'"));
		mysqli_query($conn, "INSERT INTO `khodo` SET `user_id`='".$user_id."', `id_shop`='".$idshop."',`id_loai`='".$quashop['id_loai']."',`loai`='".$quashop['loai']."',`tenvatpham`='".$quashop['tenvatpham']."'"); //quà item
		mysqli_query($conn, "INSERT INTO `lichsuqua_gioithieu` SET `user_id`='".$user_id."', `nhan`='1' , `cotmoc`='2'");
	}
}
//Cột mốc 3 -- 50 người
if ($gt>=50) {
	$cotmoc=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `lichsuqua_gioithieu` WHERE `user_id`='".$user_id."' AND `cotmoc`='3' AND `nhan`='1'"));
	if (!$cotmoc) {
		$xu=5000000; $vnd=15;
		mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`+'".$xu."',`vnd`=`vnd`+'".$vnd."' WHERE `id`='".$user_id."'"); //Quà tiền 
		$idshop=789; //->Thay id shop
		$quashop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$idshop."'"));
		mysqli_query($conn, "INSERT INTO `khodo` SET `user_id`='".$user_id."', `id_shop`='".$idshop."',`id_loai`='".$quashop['id_loai']."',`loai`='".$quashop['loai']."',`tenvatpham`='".$quashop['tenvatpham']."'"); //quà item
		mysqli_query($conn, "INSERT INTO `lichsuqua_gioithieu` SET `user_id`='".$user_id."', `nhan`='1' , `cotmoc`='3'");
	}
}
//Cột mốc 4 -- 80 người
if ($gt>=80) {
	$cotmoc=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `lichsuqua_gioithieu` WHERE `user_id`='".$user_id."' AND `cotmoc`='4' AND `nhan`='1'"));
	if (!$cotmoc) {
		$xu=1000000; $vnd=15;
		mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`+'".$xu."',`vnd`=`vnd`+'".$vnd."' WHERE `id`='".$user_id."'"); //Quà tiền 
		$idshop=790; //->Thay id shop
		$quashop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$idshop."'"));
		mysqli_query($conn, "INSERT INTO `khodo` SET `user_id`='".$user_id."', `id_shop`='".$idshop."',`id_loai`='".$quashop['id_loai']."',`loai`='".$quashop['loai']."',`tenvatpham`='".$quashop['tenvatpham']."'"); //quà item
		mysqli_query($conn, "INSERT INTO `lichsuqua_gioithieu` SET `user_id`='".$user_id."', `nhan`='1' , `cotmoc`='4'");
	}
}
//Cột mốc 5 -- 100 người
if ($gt>=100) {
	$cotmoc=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `lichsuqua_gioithieu` WHERE `user_id`='".$user_id."' AND `cotmoc`='5' AND `nhan`='1'"));
	if (!$cotmoc) {
		$xu=20000000; $vnd=25;
		mysqli_query($conn, "UPDATE `users` SET `xu`=`xu`+'".$xu."',`vnd`=`vnd`+'".$vnd."' WHERE `id`='".$user_id."'"); //Quà tiền 
		$idshop=791; //->Thay id shop
		$quashop=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `shopdo` WHERE `id`='".$idshop."'"));
		mysqli_query($conn, "INSERT INTO `khodo` SET `user_id`='".$user_id."', `id_shop`='".$idshop."',`id_loai`='".$quashop['id_loai']."',`loai`='".$quashop['loai']."',`tenvatpham`='".$quashop['tenvatpham']."'"); //quà item
		mysqli_query($conn, "INSERT INTO `lichsuqua_gioithieu` SET `user_id`='".$user_id."', `nhan`='1' , `cotmoc`='5'");
	}
}
?>                                                      
                            
                            
                            
                            