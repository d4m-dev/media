<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$songvatnuoi = mysqli_query($conn, "select `id`, `timesong`, `id_vatnuoi` from `farm_vatnuoi_cuaban` WHERE `user_id` = '".$user_id."'");
while ($chiso = mysqli_fetch_array($songvatnuoi)) {
$tinhtrangsong = mysqli_fetch_array(mysqli_query($conn, "select * from `farm_vatnuoi` WHERE `id` = '".$chiso[id_vatnuoi]."'"));
if (($chiso[timesong] + $tinhtrangsong[timesong]) < $time) {
mysqli_query($conn, "DELETE FROM `farm_vatnuoi_cuaban` WHERE `id` = '".$chiso[id]."'");
mysqli_query($conn, "DELETE FROM `farm_vatnuoi_choan` WHERE `sid` = '".$chiso[id]."'");
header('Location: '.$home.'/farm/');
}
}
?>