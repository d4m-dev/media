<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl = 'Upload ảnh';
require('../incfiles/head.php');

if($style == "web") echo '<div class="bodyf"><div class="container">';
$id = intval($_GET['id']);

$reg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `imgupload` WHERE `id` = '$id'"));
$kt = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = {$reg['user']}"));
$check = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `imgupload` WHERE `id` = '$id'"),0);

if($datauser['name'] == $kt['name']){
if($check >0){
if(isset($_POST['submit'])){
mysqli_query($conn, "DELETE FROM `imgupload` WHERE `id` = '$id'");
echo '<div class="list1">Bạn đã xóa file ảnh thành công</div>';
} else {
echo '<div class="phdr">Xóa file</div><div class="list1">Bạn muốn xóa file ảnh đã chọn<br /><form method="POST"><input type="submit" name="submit" value="Xóa">&#160;&#160;<a href="index.php"><input type="button" value="Hủy" /></a></form>';
}
} else {
echo '<div class="rmenu">File ảnh không tồn tại</div>';
} 
} else {
if($rights >=3 && $rights >= $kt['rights']){
if($check >0){
if(isset($_POST['submit'])){
mysqli_query($conn, "DELETE FROM `imgupload` WHERE `id` = '$id'");
echo '<div class="list1">Bạn đã xóa file ảnh thành công</div>';
} else {
echo '<div class="phdr">Xóa file</div><div class="list1">Bạn muốn xóa file ảnh đã chọn<br /><form method="POST"><input type="submit" name="submit" value="Xóa">&#160;&#160;<a href="index.php"><input type="button" value="Hủy" /></a></form>';
}
} else {
echo '<div class="rmenu">File ảnh không tồn tại</div>';
}
} else {
echo '<div class="rmenu">Bạn không đủ quyền để xóa ảnh này</div>';
}



}
require('../incfiles/end.php');
?>
