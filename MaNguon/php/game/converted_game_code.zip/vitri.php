<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$checkvt=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM `vitri` WHERE `user_id`='".$user_id."'"));
if ($checkvt<1) {
mysqli_query($conn, "INSERT INTO `vitri` SET
`user_id`='".$user_id."'");
}
?>