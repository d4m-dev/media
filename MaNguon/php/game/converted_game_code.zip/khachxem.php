<?php
$conn = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
if (!$conn) { die('Connection failed: ' . mysqli_connect_error()); }
?>
<?php
$online = // mysql_result not supported in mysqli. Needs manual rewrite.mysqli_query($conn, "SELECT COUNT(*) FROM `users` WHERE `lastdate` > " . (time() - 30) . " AND `place` = 'arena'"),0); 
if ($online > 0) {
echo'</div>';
echo'<div class="main-xmenu">';
echo'<div class="danhmuc">Khách Xem</div>';
echo '<div class="menu">';
//--code này copy để hiện avatar by cRoSsOver--//
//update nơi đang online và tọa độ
mysqli_query($conn, "UPDATE `vitri` SET `time`='".time()."',`online`='arena',`toado`='".$toado."' WHERE `user_id`='".$user_id."'");
$time=time()-300;
//bắt đầu cho hiện avatar
$req=mysqli_query($conn, "SELECT * FROM `vitri` WHERE `online`='arena' AND `time`>'".$time."'");
while($pr = mysqli_fetch_array($req))
    {
$name=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM `users` WHERE `id`='".$pr[user_id]."'"));
$flip=rand(1,2);
if($flip==1) {$flip=' class="flip"';}
else {$flip='';}
        echo '<a href="/member/'.$pr['user_id'].'.html"><label style="display: inline-block;text-align: center;"><b style="font-size: 9px;color:red;font-weight:bold;text-align: center;">'.$name[name].'</b><br><img src="/avatar/'.$pr[user_id].'.png"></label></a>';
    }
//end avatar
echo '</div>';
}
?>